package (package_name).UserAuth.Enum;

public enum Role {

    USER,
    ADMIN,
}
