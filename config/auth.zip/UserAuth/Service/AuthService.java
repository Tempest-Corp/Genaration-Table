package (package_name).UserAuth.Service;

import java.util.List;
import java.util.Optional;


import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;

import (package_name).UserAuth.Auth.AuthenticationResponse;
import (package_name).UserAuth.Auth.RefreshToken;
import (package_name).UserAuth.Config.JwtService;
import (package_name).UserAuth.Enum.Role;
import (package_name).UserAuth.Models.User;
import (package_name).UserAuth.Repository.UserRepository;
import (package_name).UserAuth.Request.AuthenticationRequest;
import (package_name).UserAuth.Request.RefreshTokenRequest;
import (package_name).UserAuth.Request.RegisterRequest;
import (package_name).UserAuth.Response.RegisterData;
import (package_name).utils.Status;

import lombok.RequiredArgsConstructor;

@org.springframework.stereotype.Service
@RequiredArgsConstructor
public class AuthService {

       private final UserRepository repository;
        private final PasswordEncoder passwordEncoder;
        private final JwtService jwtService;
        private final AuthenticationManager authenticationManager;
        private final RefreshTokenService refreshTokenService;

        public AuthenticationResponse register(RegisterRequest request) {
                User user = User.builder().firstname(request.getFirstname()).lastname(request.getLastname())
                                .email(request.getEmail()).password(passwordEncoder.encode(request.getPassword()))
                                .roles(Role.ADMIN).build();
                user = repository.save(user);
                return getAuthResponse(user);
        }



        public Role getRole(String roleS) {
                return Role.valueOf(roleS.toUpperCase());
        }

        public AuthenticationResponse authenticate(AuthenticationRequest request) {
                authenticationManager.authenticate(
                                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
                User user = repository.findByEmail(request.getEmail()).orElseThrow();
                return getAuthResponse(user);
        }

        public AuthenticationResponse getAuthResponse(User user) {
                String jwtToken = jwtService.generateToken(user);
                RefreshToken tokenRefresh = refreshTokenService.generateRefreshToken(user.getEmail());
                return AuthenticationResponse.builder().token(jwtToken).user(user)
                                .refresh_token(tokenRefresh.getToken())
                                .build();
        }

        public Status useRefreshToken(RefreshTokenRequest refreshTokenRequest) {
                User user = refreshTokenService.findByToken(refreshTokenRequest.getRefresh_token()).map(
                                refreshTokenService::verifyExpiration).map(RefreshToken::getUser).get();
                String accesToken = jwtService.generateToken(user);
                var tokenRefresh = refreshTokenService.generateRefreshToken(user.getEmail());
                
                return new Status("good", "token removed", AuthenticationResponse.builder().token(accesToken).user(user)
                                .refresh_token(tokenRefresh.getToken())
                                .build());
        }

        public Boolean chekcIfAlreadyExist(String email) {
                Boolean exist = false;
                Optional<User> user = repository.findByEmail(email);
                if (user.isPresent())
                        exist = true;

                return exist;
        }
}
