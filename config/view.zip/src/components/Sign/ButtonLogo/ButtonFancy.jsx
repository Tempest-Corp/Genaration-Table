import React from "react";

const ButtonFancy = () => {
  return <a class="btn_fancy cta bg">Login</a>;
};

export default ButtonFancy;
