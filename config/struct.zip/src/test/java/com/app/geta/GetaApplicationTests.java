package com.app.geta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetaApplicationTests {

	@Test
	void contextLoads() {
	}

}
