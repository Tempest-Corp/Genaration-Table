package com.app.geta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetaApplication.class, args);
	}

}
